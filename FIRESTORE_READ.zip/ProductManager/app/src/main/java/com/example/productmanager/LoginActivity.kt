package com.example.productmanager

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : ComponentActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = FirebaseAuth.getInstance()

        // Verifica se o usuário já está autenticado
        if (auth.currentUser != null) {
            abrirTelaPrincipal()
            return
        }

        val email = findViewById<EditText>(R.id.edtEmail)
        val senha = findViewById<EditText>(R.id.edtSenha)

        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnCadastrar = findViewById<Button>(R.id.btnCadastrar)

        val recuperarSenha =
            findViewById<TextView>(R.id.txtRecuperarSenha)

        // Login
        btnLogin.setOnClickListener {

            val emailTexto = email.text.toString().trim()
            val senhaTexto = senha.text.toString()

            if (emailTexto.isEmpty() || senhaTexto.isEmpty()) {
                Toast.makeText(
                    this,
                    "Preencha e-mail e senha",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            auth.signInWithEmailAndPassword(
                emailTexto,
                senhaTexto
            ).addOnCompleteListener(this) { task ->

                if (task.isSuccessful) {

                    Toast.makeText(
                        this,
                        "Login realizado com sucesso!",
                        Toast.LENGTH_SHORT
                    ).show()

                    abrirTelaPrincipal()

                } else {

                    Toast.makeText(
                        this,
                        task.exception?.message ?: "Erro ao entrar",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }

        // Abrir cadastro
        btnCadastrar.setOnClickListener {
            startActivity(
                Intent(this, CadastroActivity::class.java)
            )
        }

        // Recuperação de senha
        recuperarSenha.setOnClickListener {

            val emailTexto = email.text.toString().trim()

            if (emailTexto.isEmpty()) {
                Toast.makeText(
                    this,
                    "Digite seu e-mail primeiro",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            auth.sendPasswordResetEmail(emailTexto)
                .addOnCompleteListener(this) { task ->

                    if (task.isSuccessful) {

                        Toast.makeText(
                            this,
                            "E-mail de recuperação enviado!",
                            Toast.LENGTH_LONG
                        ).show()

                    } else {

                        Toast.makeText(
                            this,
                            task.exception?.message
                                ?: "Erro ao enviar e-mail",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
        }
    }

    private fun abrirTelaPrincipal() {
        startActivity(
            Intent(this, MainActivity::class.java)
        )
        finish()
    }
}
