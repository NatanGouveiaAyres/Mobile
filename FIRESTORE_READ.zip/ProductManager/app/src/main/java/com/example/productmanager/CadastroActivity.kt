package com.example.productmanager

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.google.firebase.auth.FirebaseAuth

class CadastroActivity : ComponentActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        auth = FirebaseAuth.getInstance()

        val email = findViewById<EditText>(R.id.edtEmailCadastro)
        val senha = findViewById<EditText>(R.id.edtSenhaCadastro)
        val confirmarSenha = findViewById<EditText>(R.id.edtConfirmarSenha)

        val btnCadastrar = findViewById<Button>(R.id.btnCriarConta)
        val btnVoltar = findViewById<Button>(R.id.btnVoltarLogin)

        btnCadastrar.setOnClickListener {

            val emailTexto = email.text.toString().trim()
            val senhaTexto = senha.text.toString()
            val confirmarTexto = confirmarSenha.text.toString()

            if (emailTexto.isEmpty() ||
                senhaTexto.isEmpty() ||
                confirmarTexto.isEmpty()
            ) {
                Toast.makeText(
                    this,
                    "Preencha todos os campos",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            if (senhaTexto != confirmarTexto) {
                Toast.makeText(
                    this,
                    "As senhas não coincidem",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            auth.createUserWithEmailAndPassword(
                emailTexto,
                senhaTexto
            ).addOnCompleteListener(this) { task ->

                if (task.isSuccessful) {

                    Toast.makeText(
                        this,
                        "Conta criada com sucesso!",
                        Toast.LENGTH_SHORT
                    ).show()

                    startActivity(
                        Intent(this, MainActivity::class.java)
                    )

                    finish()

                } else {

                    Toast.makeText(
                        this,
                        task.exception?.message ?: "Erro ao cadastrar",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }

        btnVoltar.setOnClickListener {
            finish()
        }
    }
}
