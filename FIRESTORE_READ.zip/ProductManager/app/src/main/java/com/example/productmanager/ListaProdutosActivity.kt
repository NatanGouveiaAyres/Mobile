package com.example.productmanager

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class ListaProdutosActivity : ComponentActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var recyclerProdutos: RecyclerView
    private lateinit var txtListaVazia: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_produtos)

        db = FirebaseFirestore.getInstance()

        recyclerProdutos = findViewById(R.id.recyclerProdutos)
        txtListaVazia = findViewById(R.id.txtListaVazia)

        val btnVoltar = findViewById<Button>(R.id.btnVoltar)

        recyclerProdutos.layoutManager = LinearLayoutManager(this)

        btnVoltar.setOnClickListener {
            finish()
        }

        carregarProdutos()
    }

    private fun carregarProdutos() {
        db.collection("Produtos")
            .get()
            .addOnSuccessListener { resultado ->

                val produtos = resultado.documents.mapNotNull { documento ->
                    documento.toObject(Produto::class.java)
                }

                if (produtos.isEmpty()) {
                    recyclerProdutos.visibility = View.GONE
                    txtListaVazia.visibility = View.VISIBLE
                } else {
                    recyclerProdutos.visibility = View.VISIBLE
                    txtListaVazia.visibility = View.GONE

                    recyclerProdutos.adapter = ProdutoAdapter(produtos)
                }
            }
            .addOnFailureListener { erro ->
                Toast.makeText(
                    this,
                    "Erro ao carregar produtos: ${erro.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }
}