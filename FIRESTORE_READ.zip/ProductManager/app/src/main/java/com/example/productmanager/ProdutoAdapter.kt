package com.example.productmanager

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.NumberFormat
import java.util.Locale

class ProdutoAdapter(
    private val produtos: List<Produto>
) : RecyclerView.Adapter<ProdutoAdapter.ProdutoViewHolder>() {

    class ProdutoViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        val nome: TextView = itemView.findViewById(R.id.txtNomeProduto)
        val categoria: TextView = itemView.findViewById(R.id.txtCategoriaProduto)
        val preco: TextView = itemView.findViewById(R.id.txtPrecoProduto)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ProdutoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_produto, parent, false)

        return ProdutoViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: ProdutoViewHolder,
        position: Int
    ) {
        val produto = produtos[position]

        holder.nome.text = produto.nome
        holder.categoria.text = "Categoria: ${produto.categoria}"

        val formatoMoeda = NumberFormat.getCurrencyInstance(
            Locale("pt", "BR")
        )

        holder.preco.text = formatoMoeda.format(produto.preco)
    }

    override fun getItemCount(): Int {
        return produtos.size
    }
}