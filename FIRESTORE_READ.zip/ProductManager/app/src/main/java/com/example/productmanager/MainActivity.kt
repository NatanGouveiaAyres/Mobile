package com.example.productmanager

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val nome = findViewById<EditText>(R.id.edtNome)
        val categoria = findViewById<EditText>(R.id.edtCategoria)
        val preco = findViewById<EditText>(R.id.edtPreco)

        val btnSalvar = findViewById<Button>(R.id.btnSalvarProduto)
        val btnVer = findViewById<Button>(R.id.btnVerProdutos)
        val btnSair = findViewById<Button>(R.id.btnSair)

        btnSalvar.setOnClickListener {

            val nomeTexto = nome.text.toString().trim()
            val categoriaTexto = categoria.text.toString().trim()
            val precoTexto = preco.text.toString()
                .trim()
                .replace(",", ".")

            if (nomeTexto.isEmpty() ||
                categoriaTexto.isEmpty() ||
                precoTexto.isEmpty()
            ) {
                Toast.makeText(
                    this,
                    "Preencha todos os campos",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            val precoValor = precoTexto.toDoubleOrNull()

            if (precoValor == null || precoValor < 0) {
                Toast.makeText(
                    this,
                    "Informe um preço válido",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            val produto = Produto(
                nome = nomeTexto,
                categoria = categoriaTexto,
                preco = precoValor
            )

            db.collection("Produtos")
                .add(produto)
                .addOnSuccessListener {

                    Toast.makeText(
                        this,
                        "Produto cadastrado com sucesso!",
                        Toast.LENGTH_SHORT
                    ).show()

                    nome.text.clear()
                    categoria.text.clear()
                    preco.text.clear()
                }
                .addOnFailureListener { erro ->

                    Toast.makeText(
                        this,
                        "Erro ao salvar: ${erro.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
        }

        btnVer.setOnClickListener {
            startActivity(Intent(this, ListaProdutosActivity::class.java))
        }

        btnSair.setOnClickListener {
            auth.signOut()

            startActivity(
                Intent(this, LoginActivity::class.java)
            )

            finish()
        }
    }
}
