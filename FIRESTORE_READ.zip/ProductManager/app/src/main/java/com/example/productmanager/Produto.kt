package com.example.productmanager

data class Produto(
    val nome: String = "",
    val categoria: String = "",
    val preco: Double = 0.0
)
